package com.islandify.app.island

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

// WEATHERKIT + CALLIST  (idle card: mausam + agle calendar events.)

/** Ek calendar event (idle card ki list ke liye). */
internal data class CalEvent(val title: String, val begin: Long, val end: Long)

/** Fitur cuaca DIMATIKAN di build ini: tidak ada akses internet / lokasi. Selalu mengembalikan null. */
internal object WeatherKit {
    @Suppress("UNUSED_PARAMETER")
    fun text(ctx: Context, fahrenheit: Boolean): String? = null
}

/** Agle [max] calendar events (CALKIT ke hours + accounts ke hisaab se). Needs READ_CALENDAR. IO thread. */
internal fun upcomingEvents(ctx: Context, max: Int): List<CalEvent> = runCatching {
    val granted = ContextCompat.checkSelfPermission(ctx, "android.permission.READ_CALENDAR") ==
        PackageManager.PERMISSION_GRANTED
    if (!granted) return@runCatching emptyList<CalEvent>()
    val now = System.currentTimeMillis()
    val hrs = com.islandify.app.core.IslandSettings.calHours.value.coerceIn(1, 24)
    val uri = android.provider.CalendarContract.Instances.CONTENT_URI.buildUpon().also {
        android.content.ContentUris.appendId(it, now)
        android.content.ContentUris.appendId(it, now + hrs * 3600_000L)
    }.build()
    val cols = arrayOf(
        android.provider.CalendarContract.Instances.TITLE,
        android.provider.CalendarContract.Instances.BEGIN,
        android.provider.CalendarContract.Instances.END,
        android.provider.CalendarContract.Instances.ALL_DAY,
        android.provider.CalendarContract.Calendars.ACCOUNT_NAME,
    )
    val accFilter = com.islandify.app.core.IslandSettings.calAccounts.value
    val out = ArrayList<CalEvent>()
    ctx.contentResolver.query(uri, cols, null, null, android.provider.CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
        while (c.moveToNext() && out.size < max) {
            if (c.getInt(3) == 1) continue
            val end = c.getLong(2)
            if (end < now) continue
            if (accFilter.isNotEmpty() && (c.getString(4) ?: "") !in accFilter) continue
            val title = c.getString(0)?.takeIf { it.isNotBlank() } ?: continue
            out += CalEvent(title, c.getLong(1), end)
        }
    }
    out
}.getOrDefault(emptyList())
